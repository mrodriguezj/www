<?php
$id = $_POST['id'];
$accion = $_POST['accion'];

$pagos = json_decode(file_get_contents('pagos.json'), true);
$pagos[$id]['estado'] = $accion;
file_put_contents('pagos.json', json_encode($pagos, JSON_PRETTY_PRINT));
header("Location: admin.php");
?>