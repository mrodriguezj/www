<?php
$pagos = json_decode(file_get_contents('pagos.json'), true);
?>

<h2>Pagos Reportados</h2>
<?php foreach ($pagos as $i => $p): ?>
  <div style="border:1px solid #ccc; margin:10px; padding:10px;">
    <p><strong>Teléfono:</strong> <?= $p['telefono'] ?></p>
    <p><strong>Propiedad:</strong> <?= $p['propiedad'] ?></p>
    <p><strong>Monto:</strong> $<?= $p['monto'] ?></p>
    <p><strong>Archivo:</strong> <a href="<?= $p['archivo'] ?>" target="_blank">Ver</a></p>
    <p><strong>Estado:</strong> <?= $p['estado'] ?></p>
    <form method="post" action="validar_pago.php">
      <input type="hidden" name="id" value="<?= $i ?>">
      <button name="accion" value="validado">Validar</button>
      <button name="accion" value="rechazado">Rechazar</button>
    </form>
  </div>
<?php endforeach; ?>