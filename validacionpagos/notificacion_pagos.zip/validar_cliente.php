<?php
$telefono = $_POST['telefono'];
$propiedad = $_POST['propiedad'];
$clientes = json_decode(file_get_contents('clientes.json'), true);

$valido = false;
foreach ($clientes as $c) {
  if ($c['telefono'] === $telefono && $c['propiedad'] === $propiedad) {
    $valido = true;
    break;
  }
}
echo json_encode(['valido' => $valido]);
?>