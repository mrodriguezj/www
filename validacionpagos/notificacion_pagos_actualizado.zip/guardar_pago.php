<?php
$telefono = $_POST['telefono'];
$propiedad = $_POST['propiedad'];
$monto = $_POST['monto'];
$archivo = $_FILES['evidencia'];

$pagos = file_exists('pagos.json') ? json_decode(file_get_contents('pagos.json'), true) : [];

// Verificar duplicado exacto (teléfono, propiedad, monto) con estado pendiente o validado
foreach ($pagos as $p) {
    if (
        $p['telefono'] === $telefono &&
        $p['propiedad'] === $propiedad &&
        $p['monto'] === $monto &&
        in_array($p['estado'], ['pendiente', 'validado'])
    ) {
        echo "Ya has reportado un pago con estos datos. Por favor espera validación.";
        exit;
    }
}

$nombre_archivo = time() . "_" . basename($archivo['name']);
$ruta_destino = "evidencias/" . $nombre_archivo;
move_uploaded_file($archivo['tmp_name'], $ruta_destino);

$pago = [
  'telefono' => $telefono,
  'propiedad' => $propiedad,
  'monto' => $monto,
  'archivo' => $ruta_destino,
  'estado' => 'pendiente',
  'fecha' => date('Y-m-d H:i:s')
];

$pagos[] = $pago;
file_put_contents('pagos.json', json_encode($pagos, JSON_PRETTY_PRINT));

echo "Tu pago ha sido enviado y está en validación.";
?>